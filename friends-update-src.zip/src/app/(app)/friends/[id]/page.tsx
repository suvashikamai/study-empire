"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { apiFetch } from "@/lib/apiClient";
import { Icon } from "@/components/icons";
import type { FriendProfileDTO, DashboardDTO } from "@/types";

export default function FriendProfilePage() {
  const params = useParams<{ id: string }>();
  const [profile, setProfile] = useState<FriendProfileDTO | null>(null);
  const [me, setMe] = useState<DashboardDTO | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<FriendProfileDTO>(`/api/friends/${params.id}`).then(setProfile).catch((e) => setError(e.message));
    apiFetch<DashboardDTO>("/api/dashboard").then(setMe).catch(() => {});
  }, [params.id]);

  if (error) return <div className="card text-empire-danger">{error}</div>;
  if (!profile) return <div className="h-80 bg-base-800 rounded-2xl animate-pulse" />;

  const { user, stats, empireSummary } = profile;

  return (
    <div className="space-y-6">
      <Link href="/friends" className="text-sm text-text-secondary hover:text-text-primary inline-flex items-center gap-1">
        <Icon name="chevron-right" className="h-3.5 w-3.5 rotate-180" /> Back to Friends
      </Link>

      <div className="card flex items-center gap-4">
        <div className="h-16 w-16 rounded-full bg-base-700 flex items-center justify-center text-2xl font-bold shrink-0">
          {user.displayName.slice(0, 1).toUpperCase()}
        </div>
        <div className="min-w-0 flex-1">
          <h1 className="text-xl font-bold truncate">{user.displayName}</h1>
          <p className="text-text-secondary text-sm">@{user.username} · Level {stats.level}</p>
          <p className="text-text-muted text-xs mt-0.5">{user.friendCode}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <MiniStat label="Streak" value={`🔥 ${stats.currentStreak}`} />
        <MiniStat label="Study Hours" value={Math.round(stats.totalStudyMinutes / 60).toLocaleString()} />
        <MiniStat label="Total XP" value={stats.totalXp.toLocaleString()} />
        <MiniStat label="Longest Streak" value={String(stats.longestStreak)} />
      </div>

      {empireSummary && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="font-semibold">{user.displayName}&apos;s World</h2>
              <p className="text-xs text-text-muted">{empireSummary.townHallName} · Town Hall Level {empireSummary.townHallLevel}</p>
            </div>
            <Link href={`/friends/${params.id}/world`} className="btn-primary text-xs px-3 py-2">
              <Icon name="castle" className="h-4 w-4" /> Visit World
            </Link>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <MiniStat label="Population" value={empireSummary.population.toLocaleString()} />
            <MiniStat label="Buildings" value={String(empireSummary.buildingCount)} />
            <MiniStat label="Condition" value={`${empireSummary.conditionPct}%`} />
          </div>
        </div>
      )}

      {me && empireSummary && (
        <div className="card">
          <h2 className="font-semibold mb-4 flex items-center gap-2">
            <Icon name="sparkles" className="h-4 w-4" /> Compare Worlds
          </h2>
          <div className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
            <div className="text-xs text-text-muted uppercase tracking-wide">You</div>
            <div className="text-xs text-text-muted uppercase tracking-wide">{user.displayName}</div>

            <div>Streak 🔥 {me.currentStreak}</div>
            <div>Streak 🔥 {stats.currentStreak}</div>

            <div>Empire XP {me.totalXp.toLocaleString()}</div>
            <div>Empire XP {stats.totalXp.toLocaleString()}</div>

            <div>Population {me.empireStatus.population.toLocaleString()}</div>
            <div>Population {empireSummary.population.toLocaleString()}</div>

            <div>Buildings {me.empireStatus.buildingCount}</div>
            <div>Buildings {empireSummary.buildingCount}</div>
          </div>
        </div>
      )}
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="card py-3 text-center">
      <div className="text-lg font-bold">{value}</div>
      <div className="text-xs text-text-muted">{label}</div>
    </div>
  );
}

