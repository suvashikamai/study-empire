"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { apiFetch } from "@/lib/apiClient";
import { Icon } from "@/components/icons";
import { CityViewer } from "@/components/empire3d/CityViewer";
import type { EmpireDTO, PublicUserDTO } from "@/types";

// Visit Mode: this page only ever GETs data and renders <CityViewer>, which
// has no edit/upgrade controls of its own (those live on the owner's own
// /empire page) — so a visitor has no way to change anything here.
export default function FriendWorldPage() {
  const params = useParams<{ id: string }>();
  const [data, setData] = useState<{ empire: EmpireDTO; friend: PublicUserDTO } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<{ empire: EmpireDTO; friend: PublicUserDTO }>(`/api/friends/${params.id}/empire`)
      .then(setData)
      .catch((e) => setError(e.message));
  }, [params.id]);

  if (error) return <div className="card text-empire-danger">{error}</div>;
  if (!data) return <div className="h-96 bg-base-800 rounded-2xl animate-pulse" />;

  const { empire, friend } = data;

  return (
    <div className="space-y-6">
      <Link href={`/friends/${params.id}`} className="text-sm text-text-secondary hover:text-text-primary inline-flex items-center gap-1">
        <Icon name="chevron-right" className="h-3.5 w-3.5 rotate-180" /> Back to {friend.displayName}&apos;s profile
      </Link>

      <div>
        <h1 className="text-2xl font-bold">{friend.displayName}&apos;s World</h1>
        <p className="text-text-secondary text-sm mt-1">{empire.townHallName} · Town Hall Level {empire.townHallLevel}</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <MiniStat label="Population" value={empire.population.toLocaleString()} />
        <MiniStat label="Empire XP" value={empire.empireXp.toLocaleString()} />
        <MiniStat label="Buildings" value={String(empire.buildings.length)} />
        <MiniStat label="City Condition" value={`${empire.conditionPct}%`} />
      </div>

      <CityViewer empire={empire} />

      <div className="flex items-start gap-2 text-xs text-text-muted">
        <Icon name="lock" className="h-4 w-4 shrink-0 mt-0.5" />
        <p>Visit mode — you can look around, but only {friend.displayName} can build or change anything here.</p>
      </div>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="card py-3 text-center">
      <div className="text-lg font-bold">{value}</div>
      <div className="text-xs text-text-muted">{label}</div>
    </div>
  );
}
