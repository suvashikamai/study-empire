"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { apiFetch } from "@/lib/apiClient";
import { Icon } from "@/components/icons";
import type { FriendsListDTO, FriendSearchResultDTO } from "@/types";

export default function FriendsPage() {
  const [list, setList] = useState<FriendsListDTO | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [query, setQuery] = useState("");
  const [results, setResults] = useState<FriendSearchResultDTO[]>([]);
  const [searching, setSearching] = useState(false);
  const [pendingId, setPendingId] = useState<string | null>(null);

  function loadList() {
    apiFetch<FriendsListDTO>("/api/friends").then(setList).catch((e) => setError(e.message));
  }
  useEffect(loadList, []);

  // Debounced search — avoids firing a request on every keystroke.
  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults([]);
      return;
    }
    setSearching(true);
    const handle = setTimeout(() => {
      apiFetch<{ results: FriendSearchResultDTO[] }>(`/api/friends/search?q=${encodeURIComponent(trimmed)}`)
        .then((d) => setResults(d.results))
        .catch((e) => setError(e.message))
        .finally(() => setSearching(false));
    }, 350);
    return () => clearTimeout(handle);
  }, [query]);

  async function sendRequest(toUserId: string) {
    setPendingId(toUserId);
    try {
      await apiFetch("/api/friends", { method: "POST", body: JSON.stringify({ toUserId }) });
      setResults((rs) => rs.map((r) => (r.id === toUserId ? { ...r, relationship: "REQUEST_SENT" } : r)));
      loadList();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't send that request.");
    } finally {
      setPendingId(null);
    }
  }

  async function respond(requestId: string, action: "accept" | "decline") {
    setPendingId(requestId);
    try {
      await apiFetch(`/api/friends/requests/${requestId}/${action}`, { method: "POST" });
      loadList();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't update that request.");
    } finally {
      setPendingId(null);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Friends</h1>
        <p className="text-text-secondary text-sm mt-1">Find people, grow your network, and visit their worlds.</p>
      </div>

      {error && (
        <div className="text-sm text-empire-danger bg-empire-danger/10 rounded-lg px-3 py-2 flex items-center justify-between">
          {error}
          <button onClick={() => setError(null)} className="shrink-0"><Icon name="x" className="h-4 w-4" /></button>
        </div>
      )}

      <div className="card space-y-3">
        <label className="label">Find friends</label>
        <input
          className="input"
          placeholder="Search by username, name, or friend code..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        {searching && <p className="text-xs text-text-muted">Searching...</p>}
        {!searching && query.trim().length >= 2 && results.length === 0 && (
          <p className="text-xs text-text-muted">No one found matching &ldquo;{query}&rdquo;.</p>
        )}
        <div className="space-y-2">
          {results.map((r) => (
            <div key={r.id} className="flex items-center justify-between gap-3 rounded-xl bg-base-800 px-3 py-2.5">
              <div className="flex items-center gap-3 min-w-0">
                <Avatar name={r.displayName} />
                <div className="min-w-0">
                  <div className="text-sm font-medium truncate">{r.displayName}</div>
                  <div className="text-xs text-text-muted truncate">@{r.username} · Level {r.level}</div>
                </div>
              </div>
              <RelationshipAction relationship={r.relationship} pending={pendingId === r.id} onAdd={() => sendRequest(r.id)} />
            </div>
          ))}
        </div>
      </div>

      {!list ? (
        <div className="h-40 bg-base-800 rounded-2xl animate-pulse" />
      ) : (
        <>
          {list.incoming.length > 0 && (
            <div className="card space-y-3">
              <h2 className="font-semibold">Friend requests ({list.incoming.length})</h2>
              <div className="space-y-2">
                {list.incoming.map((r) => (
                  <div key={r.requestId} className="flex items-center justify-between gap-3 rounded-xl bg-base-800 px-3 py-2.5">
                    <div className="flex items-center gap-3 min-w-0">
                      <Avatar name={r.user.displayName} />
                      <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{r.user.displayName}</div>
                        <div className="text-xs text-text-muted truncate">@{r.user.username}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => respond(r.requestId, "accept")}
                        disabled={pendingId === r.requestId}
                        className="btn-primary text-xs px-2.5 py-1.5"
                      >
                        Accept
                      </button>
                      <button
                        onClick={() => respond(r.requestId, "decline")}
                        disabled={pendingId === r.requestId}
                        className="btn-ghost text-xs px-2.5 py-1.5"
                      >
                        Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-3">
            <h2 className="font-semibold">
              My Friends {list.friends.length > 0 && `(${list.friends.length})`}
            </h2>
            {list.friends.length === 0 ? (
              <div className="card text-center py-8">
                <Icon name="user" className="h-8 w-8 mx-auto text-text-muted mb-2" />
                <p className="text-sm text-text-secondary">No friends yet — search above to find people you know.</p>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 gap-3">
                {list.friends.map((f) => (
                  <Link key={f.id} href={`/friends/${f.id}`} className="card flex items-center gap-3 hover:border-accent transition-colors">
                    <Avatar name={f.displayName} />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium truncate">{f.displayName}</div>
                      <div className="text-xs text-text-muted truncate">@{f.username} · Level {f.level}</div>
                    </div>
                    <Icon name="chevron-right" className="h-4 w-4 text-text-muted shrink-0" />
                  </Link>
                ))}
              </div>
            )}
          </div>

          {list.outgoing.length > 0 && (
            <div>
              <h2 className="font-semibold mb-3">Sent requests ({list.outgoing.length})</h2>
              <div className="space-y-2">
                {list.outgoing.map((r) => (
                  <div key={r.requestId} className="flex items-center gap-3 rounded-xl bg-base-800 px-3 py-2.5">
                    <Avatar name={r.user.displayName} />
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">{r.user.displayName}</div>
                      <div className="text-xs text-text-muted">Waiting for them to accept</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function RelationshipAction({
  relationship,
  pending,
  onAdd,
}: {
  relationship: FriendSearchResultDTO["relationship"];
  pending: boolean;
  onAdd: () => void;
}) {
  if (relationship === "FRIENDS") return <span className="text-xs text-accent font-medium shrink-0">Friends</span>;
  if (relationship === "REQUEST_SENT") return <span className="text-xs text-text-muted shrink-0">Request sent</span>;
  if (relationship === "REQUEST_RECEIVED") return <span className="text-xs text-text-muted shrink-0">Check requests below</span>;
  return (
    <button onClick={onAdd} disabled={pending} className="btn-secondary text-xs px-2.5 py-1.5 shrink-0">
      Add friend
    </button>
  );
}

function Avatar({ name }: { name: string }) {
  return (
    <div className="h-9 w-9 rounded-full bg-base-700 flex items-center justify-center text-sm font-semibold shrink-0">
      {name.slice(0, 1).toUpperCase()}
    </div>
  );
}
