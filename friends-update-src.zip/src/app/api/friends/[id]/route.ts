import { NextResponse } from "next/server";
import { requireUser, jsonError, ApiError } from "@/lib/api-helpers";
import { findUserById } from "@/lib/db/repo/users";
import { areFriends } from "@/lib/db/repo/friends";
import { getEmpireByUserId, listBuildings } from "@/lib/db/repo/empire";
import { getTownHallLevelConfig } from "@/game-engine/config/townhall.config";
import { mapPublicUser } from "@/lib/mappers";
import type { FriendProfileDTO } from "@/types";

// Deliberately does NOT call CityConditionService.reconcile() — visiting a
// friend's profile must never mutate their empire. Only the owner's own
// page load (GET /api/empire) reconciles decay.
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireUser();
    if (params.id === user.id) throw new ApiError(400, "That's your own profile — see it under Profile.");
    if (!areFriends(user.id, params.id)) throw new ApiError(403, "You're not friends with this person yet.");

    const friend = findUserById(params.id);
    if (!friend) throw new ApiError(404, "This user no longer exists.");

    const empire = getEmpireByUserId(friend.id);
    const buildingCount = empire ? listBuildings(empire.id).length : 0;

    const body: FriendProfileDTO = {
      user: mapPublicUser(friend),
      stats: {
        level: friend.level,
        totalXp: friend.total_xp,
        currentStreak: friend.current_streak,
        longestStreak: friend.longest_streak,
        totalStudyMinutes: friend.total_study_minutes,
      },
      empireSummary: empire
        ? {
            townHallLevel: empire.town_hall_level,
            townHallName: getTownHallLevelConfig(empire.town_hall_level).name,
            population: empire.population,
            buildingCount,
            conditionPct: Math.round(empire.condition_pct),
          }
        : null,
    };
    return NextResponse.json(body);
  } catch (err) {
    return jsonError(err);
  }
}
