import { NextResponse } from "next/server";
import { requireUser, jsonError, ApiError } from "@/lib/api-helpers";
import { findUserById } from "@/lib/db/repo/users";
import { areFriends } from "@/lib/db/repo/friends";
import { getEmpireByUserId, listBuildings } from "@/lib/db/repo/empire";
import { mapEmpire, mapPublicUser } from "@/lib/mappers";

// Read-only by construction: this route has no corresponding PATCH/POST,
// and — unlike GET /api/empire — never calls CityConditionService.reconcile,
// so simply visiting a friend's world can never change their data.
export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireUser();
    if (!areFriends(user.id, params.id)) throw new ApiError(403, "You're not friends with this person yet.");

    const friend = findUserById(params.id);
    if (!friend) throw new ApiError(404, "This user no longer exists.");

    const empire = getEmpireByUserId(friend.id);
    if (!empire) throw new ApiError(404, "This friend hasn't started their empire yet.");

    const buildings = listBuildings(empire.id);
    return NextResponse.json({ empire: mapEmpire(empire, buildings), friend: mapPublicUser(friend) });
  } catch (err) {
    return jsonError(err);
  }
}
