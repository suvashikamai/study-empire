import { NextRequest, NextResponse } from "next/server";
import { requireUser, jsonError, ApiError } from "@/lib/api-helpers";
import { findUserById } from "@/lib/db/repo/users";
import {
  friendUserIdsOf,
  listIncomingRequests,
  listOutgoingRequests,
  sendFriendRequest,
} from "@/lib/db/repo/friends";
import { mapPublicUser } from "@/lib/mappers";
import type { FriendsListDTO } from "@/types";

export async function GET() {
  try {
    const user = await requireUser();

    const friends = friendUserIdsOf(user.id)
      .map((id) => findUserById(id))
      .filter((row): row is NonNullable<typeof row> => !!row)
      .map(mapPublicUser);

    const incoming = listIncomingRequests(user.id)
      .map((r) => {
        const fromUser = findUserById(r.from_user_id);
        if (!fromUser) return null;
        return { requestId: r.id, user: mapPublicUser(fromUser), createdAt: r.created_at };
      })
      .filter((r): r is NonNullable<typeof r> => !!r);

    const outgoing = listOutgoingRequests(user.id)
      .map((r) => {
        const toUser = findUserById(r.to_user_id);
        if (!toUser) return null;
        return { requestId: r.id, user: mapPublicUser(toUser), createdAt: r.created_at };
      })
      .filter((r): r is NonNullable<typeof r> => !!r);

    const body: FriendsListDTO = { friends, incoming, outgoing };
    return NextResponse.json(body);
  } catch (err) {
    return jsonError(err);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await req.json().catch(() => ({}));
    const toUserId = typeof body?.toUserId === "string" ? body.toUserId : null;
    if (!toUserId) throw new ApiError(400, "Missing toUserId.");
    if (!findUserById(toUserId)) throw new ApiError(404, "That user doesn't exist.");

    const result = sendFriendRequest(user.id, toUserId);
    return NextResponse.json(result);
  } catch (err) {
    return jsonError(err);
  }
}
