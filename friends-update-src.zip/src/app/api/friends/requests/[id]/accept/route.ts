import { NextResponse } from "next/server";
import { requireUser, jsonError } from "@/lib/api-helpers";
import { acceptFriendRequest } from "@/lib/db/repo/friends";

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  try {
    const user = await requireUser();
    acceptFriendRequest(params.id, user.id);
    return NextResponse.json({ ok: true });
  } catch (err) {
    return jsonError(err);
  }
}
