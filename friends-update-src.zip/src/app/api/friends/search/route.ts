import { NextRequest, NextResponse } from "next/server";
import { requireUser, jsonError } from "@/lib/api-helpers";
import { searchUsersByHandle } from "@/lib/db/repo/users";
import { areFriends, getPendingRequestBetween } from "@/lib/db/repo/friends";
import { mapPublicUser } from "@/lib/mappers";
import type { FriendSearchResultDTO } from "@/types";

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const q = req.nextUrl.searchParams.get("q")?.trim() ?? "";
    if (q.length < 2) return NextResponse.json({ results: [] });

    const rows = searchUsersByHandle(q, user.id, 15);
    const results: FriendSearchResultDTO[] = rows.map((row) => {
      let relationship: FriendSearchResultDTO["relationship"] = "NONE";
      if (areFriends(user.id, row.id)) relationship = "FRIENDS";
      else if (getPendingRequestBetween(user.id, row.id)) relationship = "REQUEST_SENT";
      else if (getPendingRequestBetween(row.id, user.id)) relationship = "REQUEST_RECEIVED";
      return { ...mapPublicUser(row), relationship };
    });
    return NextResponse.json({ results });
  } catch (err) {
    return jsonError(err);
  }
}
