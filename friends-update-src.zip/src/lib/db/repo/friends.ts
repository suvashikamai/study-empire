// Friends system data access. Kept deliberately simple (no SQL joins —
// callers combine this with repo/users.ts findUserById, same pattern used
// elsewhere in this codebase, e.g. mapScheduleEntry) so node:sqlite's loose
// row typing never has to be reconciled across joined tables.
import { db, transaction } from "../client";
import { generateId } from "../id";
import { ApiError } from "../../api-helpers";

export interface FriendRequestRow {
  id: string;
  from_user_id: string;
  to_user_id: string;
  status: string;
  created_at: string;
  updated_at: string;
}

export interface FriendshipRow {
  id: string;
  user_a_id: string;
  user_b_id: string;
  created_at: string;
}

/** friendships.UNIQUE(user_a_id, user_b_id) only dedupes a single ordering,
 * so every write/read here canonicalizes the pair the same way. */
function orderedPair(a: string, b: string): [string, string] {
  return a < b ? [a, b] : [b, a];
}

export function areFriends(userIdA: string, userIdB: string): boolean {
  const [a, b] = orderedPair(userIdA, userIdB);
  return !!db.prepare("SELECT 1 FROM friendships WHERE user_a_id = ? AND user_b_id = ?").get(a, b);
}

export function getPendingRequestBetween(fromUserId: string, toUserId: string): FriendRequestRow | undefined {
  return db
    .prepare("SELECT * FROM friend_requests WHERE from_user_id = ? AND to_user_id = ? AND status = 'PENDING'")
    .get(fromUserId, toUserId) as unknown as FriendRequestRow | undefined;
}

export function getFriendRequestById(id: string): FriendRequestRow | undefined {
  return db.prepare("SELECT * FROM friend_requests WHERE id = ?").get(id) as unknown as FriendRequestRow | undefined;
}

export function listIncomingRequests(userId: string): FriendRequestRow[] {
  return db
    .prepare("SELECT * FROM friend_requests WHERE to_user_id = ? AND status = 'PENDING' ORDER BY created_at DESC")
    .all(userId) as unknown as FriendRequestRow[];
}

export function listOutgoingRequests(userId: string): FriendRequestRow[] {
  return db
    .prepare("SELECT * FROM friend_requests WHERE from_user_id = ? AND status = 'PENDING' ORDER BY created_at DESC")
    .all(userId) as unknown as FriendRequestRow[];
}

function listFriendships(userId: string): FriendshipRow[] {
  return db
    .prepare("SELECT * FROM friendships WHERE user_a_id = ? OR user_b_id = ? ORDER BY created_at DESC")
    .all(userId, userId) as unknown as FriendshipRow[];
}

/** The *other* user's id for each of this user's friendships. */
export function friendUserIdsOf(userId: string): string[] {
  return listFriendships(userId).map((f) => (f.user_a_id === userId ? f.user_b_id : f.user_a_id));
}

function createFriendshipInternal(userIdA: string, userIdB: string): void {
  const [a, b] = orderedPair(userIdA, userIdB);
  db.prepare("INSERT OR IGNORE INTO friendships (id, user_a_id, user_b_id) VALUES (?, ?, ?)").run(
    generateId("frnd"),
    a,
    b,
  );
}

export type SendFriendRequestResult =
  | { outcome: "REQUEST_SENT" }
  | { outcome: "AUTO_ACCEPTED" };

/** Creates a pending request — or, if the other person already sent one to
 * us, accepts it immediately instead of leaving two redundant requests
 * pointing at each other. */
export function sendFriendRequest(fromUserId: string, toUserId: string): SendFriendRequestResult {
  return transaction(() => {
    if (fromUserId === toUserId) {
      throw new ApiError(400, "You can't send a friend request to yourself.");
    }
    if (areFriends(fromUserId, toUserId)) {
      throw new ApiError(400, "You're already friends.");
    }
    if (getPendingRequestBetween(fromUserId, toUserId)) {
      throw new ApiError(400, "You already sent a request to this person.");
    }
    const reverse = getPendingRequestBetween(toUserId, fromUserId);
    if (reverse) {
      createFriendshipInternal(fromUserId, toUserId);
      db.prepare("DELETE FROM friend_requests WHERE id = ?").run(reverse.id);
      return { outcome: "AUTO_ACCEPTED" };
    }
    db.prepare(
      "INSERT INTO friend_requests (id, from_user_id, to_user_id, status) VALUES (?, ?, ?, 'PENDING')",
    ).run(generateId("freq"), fromUserId, toUserId);
    return { outcome: "REQUEST_SENT" };
  });
}

export function acceptFriendRequest(requestId: string, currentUserId: string): void {
  transaction(() => {
    const req = getFriendRequestById(requestId);
    if (!req || req.to_user_id !== currentUserId || req.status !== "PENDING") {
      throw new ApiError(404, "This friend request is no longer available.");
    }
    createFriendshipInternal(req.from_user_id, req.to_user_id);
    db.prepare("DELETE FROM friend_requests WHERE id = ?").run(requestId);
  });
}

export function declineFriendRequest(requestId: string, currentUserId: string): void {
  const req = getFriendRequestById(requestId);
  if (!req || req.to_user_id !== currentUserId || req.status !== "PENDING") {
    throw new ApiError(404, "This friend request is no longer available.");
  }
  db.prepare("DELETE FROM friend_requests WHERE id = ?").run(requestId);
}
