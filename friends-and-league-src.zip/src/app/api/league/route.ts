import { NextRequest, NextResponse } from "next/server";
import { requireUser, jsonError } from "@/lib/api-helpers";
import { findUserById } from "@/lib/db/repo/users";
import { friendUserIdsOf } from "@/lib/db/repo/friends";
import { weeklyStatsForUser } from "@/lib/db/repo/sessions";
import { weekRange } from "@/lib/date";
import type { LeagueDTO, LeagueEntryDTO } from "@/types";

// The league is scoped to "you + your friends" — never all users — since
// the friends system already treats another person's stats as visible
// only once you're friends with them (see /api/friends/[id]); a global
// leaderboard would leak stats to people who never accepted a request.
export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const weekParam = req.nextUrl.searchParams.get("week");
    const weeksAgo = weekParam === "last" ? 1 : 0;
    const { startIso, endIsoExclusive } = weekRange(weeksAgo);

    const participantIds = [user.id, ...friendUserIdsOf(user.id)];

    const entries: LeagueEntryDTO[] = participantIds
      .map((id) => {
        const participant = findUserById(id);
        if (!participant) return null;
        const stats = weeklyStatsForUser(id, startIso, endIsoExclusive);
        return {
          userId: participant.id,
          displayName: participant.display_name,
          username: participant.username,
          profileImageUrl: participant.profile_image_url,
          isMe: participant.id === user.id,
          rank: 0, // assigned after sorting, below
          studyMinutes: stats.minutes,
          xp: stats.xp,
          sessionsCompleted: stats.sessionsCompleted,
          currentStreak: participant.current_streak,
        };
      })
      .filter((e): e is LeagueEntryDTO => !!e)
      // Ranked by XP earned that week — the same currency the rest of the
      // app already treats as the primary measure of study output.
      .sort((a, b) => b.xp - a.xp || b.studyMinutes - a.studyMinutes)
      .map((e, i) => ({ ...e, rank: i + 1 }));

    const body: LeagueDTO = { startIso, endIsoExclusive, isCurrentWeek: weeksAgo === 0, entries };
    return NextResponse.json(body);
  } catch (err) {
    return jsonError(err);
  }
}
