"use client";

import { useEffect, useState } from "react";
import { apiFetch } from "@/lib/apiClient";
import { Icon } from "@/components/icons";
import type { LeagueDTO } from "@/types";

const RANK_ICON: Record<number, string> = { 1: "🥇", 2: "🥈", 3: "🥉" };

function formatWeekLabel(startIso: string, endIsoExclusive: string): string {
  const start = new Date(startIso + "T00:00:00Z");
  const endInclusive = new Date(endIsoExclusive + "T00:00:00Z");
  endInclusive.setUTCDate(endInclusive.getUTCDate() - 1);
  const fmt = (d: Date) => d.toLocaleDateString(undefined, { month: "short", day: "numeric", timeZone: "UTC" });
  return `${fmt(start)} – ${fmt(endInclusive)}`;
}

export default function LeaguePage() {
  const [week, setWeek] = useState<"current" | "last">("current");
  const [league, setLeague] = useState<LeagueDTO | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLeague(null);
    apiFetch<LeagueDTO>(`/api/league?week=${week}`).then(setLeague).catch((e) => setError(e.message));
  }, [week]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Weekly League</h1>
        <p className="text-text-secondary text-sm mt-1">Ranked by XP earned this week — you and your friends.</p>
      </div>

      <div className="inline-flex rounded-xl bg-base-800 p-1">
        <button
          onClick={() => setWeek("current")}
          className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${week === "current" ? "bg-accent text-base-950" : "text-text-secondary"}`}
        >
          This Week
        </button>
        <button
          onClick={() => setWeek("last")}
          className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-colors ${week === "last" ? "bg-accent text-base-950" : "text-text-secondary"}`}
        >
          Last Week
        </button>
      </div>

      {error && <div className="card text-empire-danger">{error}</div>}

      {!league ? (
        <div className="h-64 bg-base-800 rounded-2xl animate-pulse" />
      ) : (
        <>
          <p className="text-xs text-text-muted">{formatWeekLabel(league.startIso, league.endIsoExclusive)}</p>

          {league.entries.length <= 1 ? (
            <div className="card text-center py-10">
              <Icon name="trophy" className="h-8 w-8 mx-auto text-text-muted mb-2" />
              <p className="text-sm text-text-secondary">
                Add some friends to start a league — right now it&apos;s just you.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {league.entries.map((e) => (
                <div
                  key={e.userId}
                  className={`card flex items-center gap-3 ${e.isMe ? "border-accent" : ""}`}
                >
                  <div className="w-8 text-center text-lg font-bold text-text-muted shrink-0">
                    {RANK_ICON[e.rank] ?? e.rank}
                  </div>
                  <div className="h-9 w-9 rounded-full bg-base-700 flex items-center justify-center text-sm font-semibold shrink-0">
                    {e.displayName.slice(0, 1).toUpperCase()}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium truncate">
                      {e.displayName} {e.isMe && <span className="text-text-muted font-normal">(You)</span>}
                    </div>
                    <div className="text-xs text-text-muted truncate">
                      {Math.round((e.studyMinutes / 60) * 10) / 10}h · {e.sessionsCompleted} sessions · 🔥 {e.currentStreak}
                    </div>
                  </div>
                  <div className="text-sm font-bold text-accent shrink-0">{e.xp.toLocaleString()} XP</div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
