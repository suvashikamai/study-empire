// Shared date/week-boundary helpers. Mirrors the private copies inside
// StudyRewardService.ts exactly (same Monday-start, UTC-based week logic)
// so the weekly league always agrees with the streak/XP system about where
// a week begins — but lives here, standalone, so nothing that already
// works (StudyRewardService) has to be touched to reuse it.
export function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

export function mondayOfWeek(iso: string): string {
  const d = new Date(iso + "T00:00:00Z");
  const day = d.getUTCDay(); // 0 Sun - 6 Sat
  const diff = (day + 6) % 7; // days since Monday
  d.setUTCDate(d.getUTCDate() - diff);
  return d.toISOString().slice(0, 10);
}

export function addDaysIso(iso: string, days: number): string {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

/** [startIso, endIsoExclusive) for the Monday-Sunday week `weeksAgo` weeks
 * before the current one (0 = this week, 1 = last week, ...). */
export function weekRange(weeksAgo: number): { startIso: string; endIsoExclusive: string } {
  const thisMonday = mondayOfWeek(todayIso());
  const startIso = addDaysIso(thisMonday, -7 * weeksAgo);
  const endIsoExclusive = addDaysIso(startIso, 7);
  return { startIso, endIsoExclusive };
}
